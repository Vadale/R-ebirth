.relm_lifecycle_started <- proc.time()
.relm_lifecycle_step <- function(phase, label) {
  t <- proc.time() - .relm_lifecycle_started
  cat(sprintf('ASYNC_STAGE %s elapsed=%.3f cpu=%.3f %s\n', phase, t[['elapsed']], t[['user.self']] + t[['sys.self']], label))
  flush(stdout())
}
.relm_lifecycle_step('begin', 'load namespaces')
.libPaths(c("/Users/runner/work/_temp/relm-vision-library", "/Users/runner/work/_temp/Library", 
"/Library/Frameworks/R.framework/Versions/4.6/Resources/site-library", 
"/Library/Frameworks/R.framework/Versions/4.6/Resources/library"
))
library(relm)
stopifnot(requireNamespace('later'), requireNamespace('promises'))
.relm_lifecycle_step('end', 'load namespaces')
new_fixture <- function(mode = 'success', steps = 100L, delay = 2L) {
  m <- relm:::new_llm(relm:::relm_check(relm:::rebirth_async_test_handle()), '<fixture>')
  relm:::relm_check(relm:::rebirth_async_test_config(m$ptr, mode, steps, delay))
  m
}
observe <- function(p) {
  x <- new.env(); x$done <- FALSE; x$count <- 0L
  promises::then(p, function(value) { x$value <- value; x$count <- x$count + 1L; x$done <- TRUE; NULL },
    function(error) { x$error <- error; x$count <- x$count + 1L; x$done <- TRUE; NULL })
  x
}
drain <- function(x, timeout = 10) {
  until <- proc.time()[['elapsed']] + timeout
  while (!x$done && proc.time()[['elapsed']] < until) later::run_now(0.05)
  stopifnot(x$done, x$count == 1L, is.null(relm:::.relm_async$job))
}
.relm_lifecycle_step('begin', "setup 001 path <- \"/Users/runner/work/R-ebirth/R-ebirth/rebirth/tests/testthat/fixtures/synthetic-llama-2l.gguf\"")
path <- "/Users/runner/work/R-ebirth/R-ebirth/rebirth/tests/testthat/fixtures/synthetic-llama-2l.gguf"
.relm_lifecycle_step('end', "setup 001 path <- \"/Users/runner/work/R-ebirth/R-ebirth/rebirth/tests/testthat/fixtures/synthetic-llama-2l.gguf\"")
.relm_lifecycle_step('begin', "setup 002 parent <- llm(path, backend = \"cpu\", gpu_layers = 0)")
parent <- llm(path, backend = "cpu", gpu_layers = 0)
.relm_lifecycle_step('end', "setup 002 parent <- llm(path, backend = \"cpu\", gpu_layers = 0)")
.relm_lifecycle_step('begin', "setup 003 sibling <- llm_ablate(parent, layer = 1, neurons = 1)")
sibling <- llm_ablate(parent, layer = 1, neurons = 1)
.relm_lifecycle_step('end', "setup 003 sibling <- llm_ablate(parent, layer = 1, neurons = 1)")
.relm_lifecycle_step('begin', "setup 004 unrelated <- llm(path, backend = \"cpu\", gpu_layers = 0)")
unrelated <- llm(path, backend = "cpu", gpu_layers = 0)
.relm_lifecycle_step('end', "setup 004 unrelated <- llm(path, backend = \"cpu\", gpu_layers = 0)")
stopifnot((proc.time() - .relm_lifecycle_started)[['elapsed']] <= 90)
.relm_lifecycle_budget_start <- proc.time()[['elapsed']]
.relm_lifecycle_step('begin', "lifecycle 001 worker <- new_fixture(\"success\", 500L, 2L)")
worker <- new_fixture("success", 500L, 2L)
.relm_lifecycle_step('end', "lifecycle 001 worker <- new_fixture(\"success\", 500L, 2L)")
.relm_lifecycle_step('begin', "lifecycle 002 result <- observe(llm_generate(worker, \"hold native execution\", seed = 1, async = TRUE))")
result <- observe(llm_generate(worker, "hold native execution", seed = 1, async = TRUE))
.relm_lifecycle_step('end', "lifecycle 002 result <- observe(llm_generate(worker, \"hold native execution\", seed = 1, async = TRUE))")
.relm_lifecycle_step('begin', "lifecycle 003 stopifnot(relm:::rebirth_async_test_stats()$active_jobs == 1)")
stopifnot(relm:::rebirth_async_test_stats()$active_jobs == 1)
.relm_lifecycle_step('end', "lifecycle 003 stopifnot(relm:::rebirth_async_test_stats()$active_jobs == 1)")
.relm_lifecycle_step('begin', "lifecycle 004 close(parent)")
close(parent)
.relm_lifecycle_step('end', "lifecycle 004 close(parent)")
.relm_lifecycle_step('begin', "lifecycle 005 close(parent)")
close(parent)
.relm_lifecycle_step('end', "lifecycle 005 close(parent)")
.relm_lifecycle_step('begin', "lifecycle 006 stopifnot(relm:::rebirth_async_test_stats()$deferred_handles == 1)")
stopifnot(relm:::rebirth_async_test_stats()$deferred_handles == 1)
.relm_lifecycle_step('end', "lifecycle 006 stopifnot(relm:::rebirth_async_test_stats()$deferred_handles == 1)")
.relm_lifecycle_step('begin', "lifecycle 007 rm(sibling, unrelated)")
rm(sibling, unrelated)
.relm_lifecycle_step('end', "lifecycle 007 rm(sibling, unrelated)")
.relm_lifecycle_step('begin', "lifecycle 008 gc()")
gc()
.relm_lifecycle_step('end', "lifecycle 008 gc()")
.relm_lifecycle_step('begin', "lifecycle 009 stats <- relm:::rebirth_async_test_stats()")
stats <- relm:::rebirth_async_test_stats()
.relm_lifecycle_step('end', "lifecycle 009 stats <- relm:::rebirth_async_test_stats()")
.relm_lifecycle_step('begin', "lifecycle 010 stopifnot(stats$active_jobs == 1, stats$deferred_handles == 3)")
stopifnot(stats$active_jobs == 1, stats$deferred_handles == 3)
.relm_lifecycle_step('end', "lifecycle 010 stopifnot(stats$active_jobs == 1, stats$deferred_handles == 3)")
.relm_lifecycle_step('begin', "lifecycle 011 drain(result)")
drain(result)
.relm_lifecycle_step('end', "lifecycle 011 drain(result)")
.relm_lifecycle_step('begin', "lifecycle 012 stopifnot(is.null(result$error), is.character(result$value))")
stopifnot(is.null(result$error), is.character(result$value))
.relm_lifecycle_step('end', "lifecycle 012 stopifnot(is.null(result$error), is.character(result$value))")
.relm_lifecycle_step('begin', "lifecycle 013 stats <- relm:::rebirth_async_test_stats()")
stats <- relm:::rebirth_async_test_stats()
.relm_lifecycle_step('end', "lifecycle 013 stats <- relm:::rebirth_async_test_stats()")
.relm_lifecycle_step('begin', "lifecycle 014 stopifnot(stats$active_jobs == 0, stats$worker_threads == 0, stats$deferred_handles == 0)")
stopifnot(stats$active_jobs == 0, stats$worker_threads == 0, stats$deferred_handles == 0)
.relm_lifecycle_step('end', "lifecycle 014 stopifnot(stats$active_jobs == 0, stats$worker_threads == 0, stats$deferred_handles == 0)")
.relm_lifecycle_step('begin', "lifecycle 015 close(worker)")
close(worker)
.relm_lifecycle_step('end', "lifecycle 015 close(worker)")
.relm_lifecycle_step('begin', "lifecycle 016 rm(parent, worker)")
rm(parent, worker)
.relm_lifecycle_step('end', "lifecycle 016 rm(parent, worker)")
.relm_lifecycle_step('begin', "lifecycle 017 gc()")
gc()
.relm_lifecycle_step('end', "lifecycle 017 gc()")
stopifnot(proc.time()[['elapsed']] - .relm_lifecycle_budget_start <= 30)
cat('ASYNC_LIFECYCLE_OK\n')
