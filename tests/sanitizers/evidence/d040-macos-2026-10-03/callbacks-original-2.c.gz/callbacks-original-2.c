#include "shared.h"
ggml_vec_dot_t original = (ggml_vec_dot_t) ggml_vec_dot_bf16;
