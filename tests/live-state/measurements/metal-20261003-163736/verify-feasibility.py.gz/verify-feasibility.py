import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback

REPO = Path('/Users/alessandrovadala/DOCUDESK/R-ebirth')
ROOT = Path('/private/tmp/relm-f6')
WORK = REPO / 'rebirth/src/rust'
MODEL = Path('/Users/alessandrovadala/Library/Caches/org.R-project.R/R/relm/qwen2.5-0.5b-instruct-q8_0.gguf')
lock = (ROOT / 'verify.lock').open('w')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
run = ROOT / ('metal-' + time.strftime('%Y%m%d-%H%M%S'))
run.mkdir()
state = dict(status='running', pid=os.getpid(), directory=str(run), started_at=time.time(), stages=[])
env = os.environ.copy()
env['R_HOME'] = subprocess.check_output(['R', 'RHOME'], text=True).strip()
env['RUST_TEST_THREADS'] = '1'
for key in list(env):
    if key.startswith(('RELM_TEST_MODEL_', 'RELM_TEST_MMPROJ_')) or key == 'RELM_NATIVE_SANITIZERS':
        env.pop(key)

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def save():
    data = json.dumps(state, indent=2) + '\n'
    (run / 'status.json').write_text(data)
    temporary = ROOT / 'active-status.tmp'
    temporary.write_text(data)
    temporary.replace(ROOT / 'active-status.json')

def stage(name, command, timeout=1800, overrides=None, allow_failure=False):
    item = dict(name=name, command=command, status='running', started_at=time.time())
    state['stages'].append(item)
    state['stage'] = name
    save()
    local_env = env.copy()
    local_env.update(overrides or {})
    with (run / (name + '.log')).open('w') as output:
        child = subprocess.Popen(command, cwd=WORK, env=local_env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        item['pid'] = child.pid
        save()
        try:
            rc = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            item.update(status='failed', reason='stage timeout', finished_at=time.time())
            save()
            raise
    item.update(status='passed' if rc == 0 else 'failed', exit_code=rc, finished_at=time.time())
    save()
    if rc and not allow_failure:
        raise RuntimeError(name + ' failed')
    return rc

save()
try:
    paths = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard', 'rebirth/src/rust', 'rebirth/src/llama.cpp', 'tests/llm-golden/live-state', 'tests/llm-golden/synthetic', 'tests/live-state/fixtures'], cwd=REPO, text=True).splitlines()
    # F6b's separate new fixture is independent work, not part of this frozen F6a attempt.
    paths = sorted(set(p for p in paths if '/f6b/' not in p and (REPO / p).is_file()))
    manifest = {p: digest(REPO / p) for p in paths}
    manifest_bytes = (json.dumps(manifest, sort_keys=True, indent=2) + '\n').encode()
    (run / 'source-manifest.json').write_bytes(manifest_bytes)
    (run / 'verify-feasibility.py').write_bytes(Path(__file__).read_bytes())
    source = hashlib.sha256(manifest_bytes).hexdigest()
    state['source_manifest_sha256'] = source
    state['scope'] = 'Metal-only preflight correction; CPU and numerical results remain scoped to feasibility-20261003-162847. No runtime change.'
    state['model_sha256'] = digest(MODEL)
    env.update(F6_MODEL=str(MODEL), F6_MODEL_SHA256=state['model_sha256'], F6_SOURCE=source)
    save()
    stage('format', ['cargo', 'fmt', '--all', '--check'])
    stage('clippy', ['cargo', 'clippy', '--locked', '--offline', '-p', 'rebirth-llm', '--all-targets', '--', '-D', 'warnings'])
    stage('metal-receipt-regression', ['cargo', 'test', '--locked', '--offline', '-p', 'rebirth-llm', '--lib', 'live_capture::tests::metal_receipt_matches_retained_pinned_device_name', '--', '--nocapture', '--test-threads=1'])
    for backend in ('metal',):
        stage('benchmark-' + backend, ['cargo', 'test', '--locked', '--offline', '-p', 'rebirth-llm', '--release', '--lib', 'live_capture::tests::live_feasibility_model', '--', '--ignored', '--nocapture', '--test-threads=1'], overrides={'F6_BACKEND': backend}, allow_failure=True)
        log = (run / ('benchmark-' + backend + '.log')).read_text()
        receipts = [json.loads(line.split('F6_RECEIPT ', 1)[1]) for line in log.splitlines() if 'F6_RECEIPT ' in line]
        gates = [json.loads(line.split('F6_GATE ', 1)[1]) for line in log.splitlines() if 'F6_GATE ' in line]
        backend_proofs = [json.loads(line.split('F6_BACKEND ', 1)[1]) for line in log.splitlines() if 'F6_BACKEND ' in line]
        (run / ('benchmark-' + backend + '.json')).write_text(json.dumps(dict(receipts=receipts, gates=gates, backend_proofs=backend_proofs), indent=2) + '\n')
        if len(receipts) != 12 or len(gates) != 1 or len(backend_proofs) != 1:
            raise RuntimeError(backend + ' benchmark did not complete its prescribed samples')
        assert all(row['source'] == source and row['model_sha256'] == state['model_sha256'] and row['build_profile'] == 'release' and row['debug_assertions'] is False and row['resolved_backend'] == backend for row in receipts)
        proof = backend_proofs[0]
        assert proof['source'] == source and proof['build_profile'] == 'release' and proof['debug_assertions'] is False
        for mode in ('callback_free', 'hooked'):
            actual = proof[mode]
            assert actual['resolved_backend'] == backend and actual['native_load_log'] and actual['compute_buffers_mib']
            if backend == 'metal':
                assert actual['offloaded_layers'] and all(a == b and a > 0 for a, b in actual['offloaded_layers'])
                names = {name.split()[0] for name in actual['selected_devices']}
                assert any(name in names and name.startswith('MTL') and name[3:].isdigit() and mib > 0 for name, mib in actual['compute_buffers_mib'])
            else:
                assert actual['gpu_layer_policy'] == 0 and not actual['selected_devices']
                assert all(name == 'CPU' for name, mib in actual['compute_buffers_mib'])
    drift = [p for p, sha in manifest.items() if not (REPO / p).is_file() or digest(REPO / p) != sha]
    state['source_drift'] = drift
    assert not drift, 'source changed during feasibility attempt'
    state['status'] = 'passed' if all(item['status'] == 'passed' for item in state['stages']) else 'failed'
    if state['status'] == 'failed':
        state['error'] = 'One or more measured feasibility gates failed; do not relax or blindly rerun.'
except Exception as error:
    state.update(status='failed', error=str(error), traceback=traceback.format_exc())
finally:
    state['finished_at'] = time.time()
    save()
