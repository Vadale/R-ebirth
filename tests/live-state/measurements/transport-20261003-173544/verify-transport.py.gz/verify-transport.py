import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback

REPO = Path('/Users/alessandrovadala/DOCUDESK/R-ebirth')
ROOT = Path('/private/tmp/relm-f6')
WORK = REPO / 'rebirth/src/rust'
MODEL = Path('/Users/alessandrovadala/Library/Caches/org.R-project.R/R/relm/qwen2.5-0.5b-instruct-q8_0.gguf')
lock = (ROOT / 'verify.lock').open('w')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
run = ROOT / ('transport-' + time.strftime('%Y%m%d-%H%M%S'))
run.mkdir()
state = dict(status='running', pid=os.getpid(), directory=str(run), started_at=time.time(), stages=[])
env = os.environ.copy()
env['R_HOME'] = subprocess.check_output(['R', 'RHOME'], text=True).strip()
env['RUST_TEST_THREADS'] = '1'
for key in list(env):
    if key.startswith(('RELM_TEST_MODEL_', 'RELM_TEST_MMPROJ_')) or key == 'RELM_NATIVE_SANITIZERS':
        env.pop(key)

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def save():
    data = json.dumps(state, indent=2) + '\n'
    (run / 'status.json').write_text(data)
    temporary = ROOT / 'active-status.tmp'
    temporary.write_text(data)
    temporary.replace(ROOT / 'active-status.json')

def stage(name, command, timeout=1800, overrides=None, allow_failure=False):
    item = dict(name=name, command=command, status='running', started_at=time.time())
    state['stages'].append(item)
    state['stage'] = name
    save()
    local_env = env.copy()
    local_env.update(overrides or {})
    with (run / (name + '.log')).open('w') as output:
        child = subprocess.Popen(command, cwd=WORK, env=local_env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        item['pid'] = child.pid
        save()
        try:
            rc = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            item.update(status='failed', reason='stage timeout', finished_at=time.time())
            save()
            raise
    item.update(status='passed' if rc == 0 else 'failed', exit_code=rc, finished_at=time.time())
    save()
    if rc and not allow_failure:
        raise RuntimeError(name + ' failed')
    return rc

save()
try:
    paths = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard',
        'rebirth/R', 'rebirth/src/rust', 'rebirth/src/llama.cpp', 'rebirth/tests/testthat',
        'tests/llm-golden/live-state', 'tests/llm-golden/synthetic'], cwd=REPO, text=True).splitlines()
    paths = sorted(set(p for p in paths if '/f6b/' not in p and (REPO / p).is_file()))
    manifest = {p: digest(REPO / p) for p in paths}
    encoded = (json.dumps(manifest, sort_keys=True, indent=2) + '\n').encode()
    (run / 'source-manifest.json').write_bytes(encoded)
    (run / 'verify-transport.py').write_bytes(Path(__file__).read_bytes())
    state['source_manifest_sha256'] = hashlib.sha256(encoded).hexdigest()
    save()
    stage('format', ['cargo', 'fmt', '--all', '--check'])
    stage('format-ffi-include', ['rustfmt', '--check', '--edition', '2021', 'rebirth-ffi/src/async_boundary.rs', 'rebirth-ffi/src/live_boundary.rs'])
    stage('clippy', ['cargo', 'clippy', '--locked', '--offline', '-p', 'rebirth-llm', '-p', 'rebirth-ffi', '--all-targets', '--', '-D', 'warnings'])
    stage('live-native', ['cargo', 'test', '--locked', '--offline', '-p', 'rebirth-llm', '--lib', 'live_', '--', '--nocapture', '--test-threads=1'])
    stage('async-boundaries', ['cargo', 'test', '--locked', '--offline', '-p', 'rebirth-llm', '--lib', 'async_job::tests', '--', '--nocapture', '--test-threads=1'])
    stage('ffi', ['cargo', 'test', '--locked', '--offline', '-p', 'rebirth-ffi', '--', '--nocapture', '--test-threads=1'])
    drift = [p for p, sha in manifest.items() if not (REPO / p).is_file() or digest(REPO / p) != sha]
    state['source_drift'] = drift
    assert not drift, 'source changed during transport verification'
    state['status'] = 'passed'
except Exception as error:
    state.update(status='failed', error=str(error), traceback=traceback.format_exc())
finally:
    state['finished_at'] = time.time()
    save()
