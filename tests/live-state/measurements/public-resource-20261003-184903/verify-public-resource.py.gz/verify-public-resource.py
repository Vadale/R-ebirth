import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback
import threading

REPO = Path('/Users/alessandrovadala/DOCUDESK/R-ebirth')
ROOT = Path('/private/tmp/relm-f6')
WORK = REPO / 'rebirth/src/rust'
MODEL = Path('/Users/alessandrovadala/Library/Caches/org.R-project.R/R/relm/qwen2.5-0.5b-instruct-q8_0.gguf')
lock = (ROOT / 'verify.lock').open('w')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
run = ROOT / ('public-resource-' + time.strftime('%Y%m%d-%H%M%S'))
run.mkdir()
state = dict(status='running', pid=os.getpid(), directory=str(run), started_at=time.time(), stages=[])
env = os.environ.copy()
env['R_HOME'] = subprocess.check_output(['R', 'RHOME'], text=True).strip()
env['RUST_TEST_THREADS'] = '1'
env['R_LIBS'] = ':'.join([str(ROOT / 'library'), '/private/tmp/relm-service/library', '/private/tmp/relm-maintenance-2026-09-27/R-library', '/Users/alessandrovadala/Library/R/arm64/4.5/library'])
env['PATH'] = '/Applications/RStudio.app/Contents/Resources/app/quarto/bin:' + env['PATH']
env['RELM_F6_EVIDENCE'] = str(run)
(ROOT / 'library').mkdir(exist_ok=True)
for key in list(env):
    if key.startswith(('RELM_TEST_MODEL_', 'RELM_TEST_MMPROJ_')) or key == 'RELM_NATIVE_SANITIZERS':
        env.pop(key)

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def save():
    data = json.dumps(state, indent=2) + '\n'
    (run / 'status.json').write_text(data)
    temporary = ROOT / 'active-status.tmp'
    temporary.write_text(data)
    temporary.replace(ROOT / 'active-status.json')

def stage(name, command, timeout=1800, overrides=None, allow_failure=False, cwd=REPO):
    item = dict(name=name, command=command, status='running', started_at=time.time())
    state['stages'].append(item)
    state['stage'] = name
    save()
    local_env = env.copy()
    local_env.update(overrides or {})
    with (run / (name + '.log')).open('w') as output:
        child = subprocess.Popen(command, cwd=cwd, env=local_env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        rss_stop = threading.Event()
        def sample_rss():
            with (run / 'rss.csv').open('w') as rss:
                rss.write('monotonic_seconds,rss_kib\n')
                while not rss_stop.is_set():
                    result = subprocess.run(['ps', '-o', 'rss=', '-p', str(child.pid)], capture_output=True, text=True)
                    value = result.stdout.strip()
                    if value.isdigit():
                        rss.write(f'{time.monotonic()},{value}\n'); rss.flush()
                    rss_stop.wait(0.1)
        sampler = threading.Thread(target=sample_rss, daemon=True); sampler.start()
        item['pid'] = child.pid
        save()
        try:
            rc = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            item.update(status='failed', reason='stage timeout', finished_at=time.time())
            save()
            raise
    rss_stop.set(); sampler.join(timeout=3)
    item.update(status='passed' if rc == 0 else 'failed', exit_code=rc, finished_at=time.time())
    save()
    if rc and not allow_failure:
        raise RuntimeError(name + ' failed')
    return rc

save()
try:
    previous = ROOT / 'package-20261003-180453'
    manifest = json.loads((previous / 'source-manifest.json').read_text())
    assert all(digest(REPO / p) == sha for p, sha in manifest.items()), 'package source drift'
    installed = json.loads((previous / 'installed-manifest.json').read_text())
    assert all(digest(ROOT / 'library' / 'relm' / p) == sha for p, sha in installed.items()), 'installed package drift'
    (run / 'source-manifest.json').write_bytes((previous / 'source-manifest.json').read_bytes())
    (run / 'installed-manifest.json').write_bytes((previous / 'installed-manifest.json').read_bytes())
    (run / 'verify-public-resource.py').write_bytes(Path(__file__).read_bytes())
    (run / 'public-resource.R').write_bytes((ROOT / 'public-resource.R').read_bytes())
    state['source_manifest_sha256'] = digest(previous / 'source-manifest.json')
    state['model_sha256'] = digest(MODEL)
    assert state['model_sha256'] == 'ca59ca7f13d0e15a8cfa77bd17e65d24f6844b554a7b6c12e07a5f89ff76844e'
    save()
    stage('public-resource', ['Rscript', '--vanilla', str(run / 'public-resource.R')], timeout=1800)
    assert 'F6_PUBLIC_RESOURCE_PASSED' in (run / 'public-resource.log').read_text()
    drift = [p for p, sha in manifest.items() if digest(REPO / p) != sha]
    state['source_drift'] = drift
    assert not drift
    state['status'] = 'passed'
except Exception as error:
    state.update(status='failed', error=str(error), traceback=traceback.format_exc())
finally:
    state['finished_at'] = time.time()
    save()
