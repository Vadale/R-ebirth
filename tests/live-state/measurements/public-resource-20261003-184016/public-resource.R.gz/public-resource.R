# Contextual RSS and all-layer throughput; not an alternative memory proof.
root <- '/private/tmp/relm-f6'
.libPaths(c(file.path(root,'library'),'/private/tmp/relm-service/library',.libPaths()))
library(relm)
stopifnot(normalizePath(find.package('relm'))==file.path(root,'library','relm'))
out <- Sys.getenv('RELM_F6_EVIDENCE'); stopifnot(dir.exists(out))
clock <- function() unname(proc.time()[['elapsed']])
model <- '/Users/alessandrovadala/Library/Caches/org.R-project.R/R/relm/qwen2.5-0.5b-instruct-q8_0.gguf'
m <- llm(model,backend='cpu',context_length=1024)
receipts <- list()
run_one <- function(mode,round) {
  old <- options(relm.trace_budget=if(mode=='spill') 64*1024 else 32*1024^2)
  on.exit(options(old))
  dir <- file.path(out,paste0(mode,'-',round)); dir.create(dir)
  done <- FALSE; error <- value <- estimate <- NULL
  states <- tokens <- 0L; callback_elapsed <- 0; max_object <- max_file <- 0
  files <- character(); rows <- list()
  started <- clock()
  p <- llm_generate(m,'1, 2, 3, 4, 5, 6, 7, 8, 9, 10,',chat=FALSE,
    max_tokens=16L,temperature=0,seed=6241,async=TRUE,layers=NULL,
    components=c('residual','attn_out','mlp_out'),top=20L,
    spill=mode=='spill',spill_dir=if(mode=='spill') dir else NULL,
    on_state=function(state) {
      entry <- clock(); states <<- states+1L
      if(is.null(estimate)) estimate <<- relm:::.relm_async$job$live$estimate
      stopifnot(state$step$state_id==states,tokens==states-1L,
        identical(attr(state$trace,'spilled'),mode=='spill'))
      bytes <- as.numeric(object.size(state)); max_object <<- max(max_object,bytes)
      stopifnot(bytes<=if(mode=='spill')estimate$logits_bytes else estimate$materialized_bytes)
      local_files <- attr(state$trace,'spill_files')
      if(length(local_files)) {
        stopifnot(all(file.exists(local_files)))
        files <<- c(files,local_files)
        max_file <<- max(max_file,file.info(local_files)$size)
      }
      Sys.sleep(0.020) # Deliberately slow consumer; included in reported throughput.
      rows[[states]] <<- data.frame(state=states,object_bytes=bytes,
        elapsed=state$step$elapsed,callback_wall=clock()-entry)
      callback_elapsed <<- callback_elapsed+clock()-entry
      invisible(NULL)
    }, on_token=function(batch) {tokens <<- tokens+sum(batch$event=='token');invisible(NULL)})
  promises::then(p,function(x){value<<-x;done<<-TRUE;NULL},function(e){error<<-e;done<<-TRUE;NULL})
  while(!done && clock()-started<120) later::run_now(.001,loop=later::global_loop())
  elapsed <- clock()-started
  actual_disk <- if(length(files)) sum(file.info(files)$size) else 0
  record <- list(mode=mode,round=round,completed=done,error=error,value=value,
    tokens=tokens,states=states,elapsed=elapsed,callback_elapsed=callback_elapsed,
    max_object_bytes=max_object,actual_disk_bytes=actual_disk,max_file_bytes=max_file,
    files=files,estimate=estimate,rows=rows)
  receipts[[length(receipts)+1L]] <<- record
  saveRDS(receipts,file.path(out,'resource-receipts.rds'))
  stopifnot(done,is.null(error),tokens==16L,states==16L,
    actual_disk<=estimate$spill_bytes,!anyDuplicated(files))
  record
}
tryCatch({
  for(round in 0:3) {
    modes <- if(round%%2L) c('spill','memory') else c('memory','spill')
    pair <- setNames(lapply(modes,function(mode)run_one(mode,round)),modes)
    stopifnot(identical(pair$memory$value,pair$spill$value))
  }
  cat('F6_PUBLIC_RESOURCE_PASSED\n')
},finally=close(m))
