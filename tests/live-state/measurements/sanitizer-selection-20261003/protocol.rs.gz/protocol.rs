#[test]
fn captured_marker() { println!("F6_GOLDEN activation_values=3840 max_activation_delta=0"); }
