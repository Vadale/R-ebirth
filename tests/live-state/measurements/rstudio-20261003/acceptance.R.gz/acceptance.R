# Foreground console only, after automated F6a acceptance. No background job.
stopifnot(Sys.getenv("RSTUDIO") == "1", !"relm" %in% loadedNamespaces(),
  length(setdiff(ls(.GlobalEnv, all.names = TRUE), ".Random.seed")) == 0L)
saveRDS(list(globals = ls(.GlobalEnv, all.names = TRUE),
  seed = get0(".Random.seed", .GlobalEnv), library = .libPaths(), search = search(),
  devices = grDevices::dev.list(), pid = Sys.getpid(), session = sessionInfo()),
  "/private/tmp/relm-f6/rstudio/preflight.rds")
.relm_f6_acceptance <- local({
  a <- new.env(parent = globalenv())
  a$root <- "/private/tmp/relm-f6/rstudio"
  a$status <- "preparing"
  a$error <- a$probe <- a$cancel_state <- a$estimate <- NULL
  a$states <- a$tokens <- a$heartbeats <- 0L
  a$first_state <- NA_real_
  a$submission <- a$duration <- NA_real_
  a$events <- list()
  a$positions <- rep(NA_integer_, 64L)
  a$scores <- rep(NA_real_, 64L)
  .libPaths(c("/private/tmp/relm-f6/library", "/private/tmp/relm-service/library", .libPaths()))
  library(relm)
  stopifnot(normalizePath(find.package("relm")) == "/private/tmp/relm-f6/library/relm",
    "on_state" %in% names(formals(llm_generate)))
  a$clock <- function() unname(proc.time()[["elapsed"]])
  a$receipt <- function() {
    receipt <- list(status = a$status, pid = Sys.getpid(),
      library = find.package("relm"), version = as.character(packageVersion("relm")),
      rstudio_version = as.character(rstudioapi::versionInfo()$version), probe = a$probe,
      states = a$states, tokens = a$tokens, heartbeats = a$heartbeats,
      first_state_seconds = a$first_state, duration_seconds = a$duration,
      submission_seconds = a$submission, cancel_state = a$cancel_state, error = a$error)
    jsonlite::write_json(receipt, file.path(a$root, "status.tmp"),
      auto_unbox = TRUE, pretty = TRUE, null = "null")
    stopifnot(file.rename(file.path(a$root, "status.tmp"), file.path(a$root, "status.json")))
  }
  a$receipt()
  a$model <- llm("/Users/alessandrovadala/Library/Caches/org.R-project.R/R/relm/qwen2.5-0.5b-instruct-q8_0.gguf",
    backend = "cpu", context_length = 2048)
  a$heartbeat <- function() {
    if (identical(a$status, "running")) {
      a$heartbeats <- a$heartbeats + 1L
      a$timer <- later::later(a$heartbeat, 0.02, loop = later::global_loop())
    }
  }
  a$finish <- function(error = NULL) {
    a$duration <- a$clock() - a$started
    if (is.function(a$timer)) a$timer()
    good <- inherits(error, "relm_error_cancelled") && !is.null(a$cancel_state) &&
      error$generated_tokens == a$cancel_state$state_id && a$states == a$cancel_state$state_id &&
      a$tokens == a$states - 1L && a$duration >= 5 && a$heartbeats >= 10L &&
      !is.null(a$probe) && isTRUE(a$probe$was_running) && isTRUE(a$probe$native_running) &&
      a$probe$states_delivered > 0L && identical(a$probe$value, 2) && a$probe$elapsed < 0.5 &&
      is.finite(a$first_state) && a$first_state < a$duration
    a$status <- if (good) "passed" else "failed"
    a$error <- if (is.null(error)) "Generation finished before the planned live cancellation gate." else
      list(class = class(error), message = conditionMessage(error), reason = error$reason,
        generated_tokens = error$generated_tokens)
    saveRDS(list(events = a$events, positions = a$positions, scores = a$scores,
      estimate = a$estimate, error = error, probe = a$probe), file.path(a$root, "result.rds"))
    if (length(a$events)) write.csv(do.call(rbind, a$events),
      file.path(a$root, "states.csv"), row.names = FALSE)
    close(a$model)
    a$receipt()
    cat("F6A_RSTUDIO_COMPLETE:", a$status, "\n")
    NULL
  }
  a$started <- a$clock()
  a$status <- "running"
  a$promise <- llm_generate(a$model,
    "Count integers from 1 to 1000, separated by commas. Do not explain.",
    max_tokens = 1024L, seed = 6241, temperature = 0, async = TRUE,
    layers = 1L, top = 5L, spill = FALSE,
    on_state = function(state) {
      a$states <- a$states + 1L
      if (is.na(a$first_state)) {
        a$first_state <- a$clock() - a$started
        a$estimate <- relm:::.relm_async$job$live$peak_bound
      }
      stopifnot(state$step$state_id == a$states, a$tokens == a$states - 1L)
      # A single neuron is a measurement mechanism, not a calibrated detector.
      value <- as.matrix(state$trace, layer = 1L)[1L, 1L]
      slot <- (a$states - 1L) %% 64L + 1L
      a$positions[[slot]] <- state$step$source_pos
      a$scores[[slot]] <- value
      a$events[[a$states]] <- cbind(state$step, score = value,
        object_bytes = as.numeric(object.size(state)))
      if (a$states %% 64L == 0L) {
        used <- which(!is.na(a$positions)); used <- used[order(a$positions[used])]
        plot(a$positions[used], a$scores[used], type = "l",
          xlab = "Model-context source position", ylab = "Neuron 1 activation",
          main = "Live observation: latest 64 states")
      }
      if (!is.null(a$probe) && a$clock() - a$started >= 6 && is.null(a$cancel_state)) {
        a$cancel_state <- state$step
        stopifnot(llm_cancel(a$model))
      }
      invisible(NULL)
    }, on_token = function(batch) {
      a$tokens <- a$tokens + sum(batch$event == "token")
      invisible(NULL)
    })
  a$submission <- a$clock() - a$started
  a$observed <- promises::then(a$promise, function(value) a$finish(), a$finish)
  a$heartbeat()
  a$receipt()
  cat("F6A_RSTUDIO_RUNNING: submit the independent 1 + 1 probe now.\n")
  a
})
