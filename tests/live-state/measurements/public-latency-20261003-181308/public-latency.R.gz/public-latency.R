# D-041 full public R transport timing. Run only after functional acceptance.
root <- "/private/tmp/relm-f6"
.libPaths(c(file.path(root, "library"), .libPaths()))
library(relm)
stopifnot(normalizePath(find.package("relm")) == file.path(root, "library", "relm"))
out <- Sys.getenv("RELM_F6_EVIDENCE")
stopifnot(nzchar(out), dir.exists(out))
model <- "/Users/alessandrovadala/Library/Caches/org.R-project.R/R/relm/qwen2.5-0.5b-instruct-q8_0.gguf"
stopifnot(file.exists(model))
clock <- function() unname(proc.time()[["elapsed"]])
prompt <- "1, 2, 3, 4, 5, 6, 7, 8, 9, 10,"
receipts <- list()
run_one <- function(m, mode, round) {
  done <- FALSE
  value <- error <- NULL
  state_count <- token_count <- 0L
  callback_elapsed <- 0
  max_object_bytes <- 0
  estimate <- NULL
  first_state <- NA_real_
  state_callback <- if (mode == "live") function(state) {
    entry <- clock()
    if (is.na(first_state)) first_state <<- entry - started
    state_count <<- state_count + 1L
    max_object_bytes <<- max(max_object_bytes, as.numeric(object.size(state)))
    job <- relm:::.relm_async$job
    if (is.null(estimate)) estimate <<- list(native = job$live$estimate, peak = job$live$peak_bound)
    callback_elapsed <<- callback_elapsed + clock() - entry
    invisible(NULL)
  } else NULL
  args <- list(m = m, prompt = prompt, chat = FALSE, max_tokens = 128L,
    temperature = 0, seed = 6241, async = TRUE,
    on_token = function(batch) { token_count <<- token_count + sum(batch$event == "token"); invisible(NULL) })
  if (!is.null(state_callback)) args <- c(args, list(on_state = state_callback,
    layers = 1L, top = 20L, spill = FALSE))
  started <- clock()
  promise <- do.call(llm_generate, args)
  submission <- clock() - started
  promises::then(promise, function(x) { value <<- x; done <<- TRUE; NULL },
    function(e) { error <<- e; done <<- TRUE; NULL })
  deadline <- started + 120
  while (!done && clock() < deadline) later::run_now(0.001, loop = later::global_loop())
  elapsed <- clock() - started
  receipt <- list(backend = m$backend, mode = mode, round = round, elapsed = elapsed,
    submission = submission, tokens = token_count, states = state_count,
    first_state = first_state, callback_elapsed = callback_elapsed,
    max_object_bytes = max_object_bytes, estimate = estimate, value = value, error = error,
    completed = done)
  receipts[[length(receipts) + 1L]] <<- receipt
  saveRDS(receipts, file.path(out, "public-latency-receipts.rds"))
  stopifnot(done, is.null(error), token_count == 128L,
    mode != "live" || state_count == token_count)
  receipt
}
for (backend in c("cpu", "metal")) {
  m <- llm(model, backend = backend, context_length = 1024)
  tryCatch({
    runs <- list()
    for (round in 0:3) {
      modes <- if (round %% 2L == 0L) c("ordinary", "live") else c("live", "ordinary")
      pair <- setNames(lapply(modes, function(mode) run_one(m, mode, round)), modes)
      stopifnot(identical(pair$ordinary$value, pair$live$value))
      if (round) runs[[length(runs) + 1L]] <- pair
    }
    ordinary <- median(vapply(runs, function(x) x$ordinary$elapsed, numeric(1)))
    live <- median(vapply(runs, function(x) x$live$elapsed, numeric(1)))
    bound <- 1.5 * ordinary + 0.010 * 128L
    gate <- data.frame(backend = backend, ordinary_median = ordinary, live_median = live,
      active_bound = bound, passed = live <= bound)
    write.csv(gate, file.path(out, paste0("public-latency-", backend, ".csv")), row.names = FALSE)
    stopifnot(gate$passed)
  }, finally = close(m))
}
cat("F6_PUBLIC_LATENCY_PASSED\n")
