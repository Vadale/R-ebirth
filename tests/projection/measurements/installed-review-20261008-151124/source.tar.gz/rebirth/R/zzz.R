# Package-level state and lifecycle (WP4 Step 5): the disk-spill session directory
# and its cleanup. Spill files live under a per-session directory below the user
# cache and are removed when the session ends. Only aged, verifiably unowned
# managed directories are swept on load; legacy or ambiguous entries are retained.

# Per-session state, private to the package. `session_dir` is created lazily on
# the first spill; `sentinel` carries the exit finalizer that removes the session
# directory.
.relm_state <- new.env(parent = emptyenv())

# The root under which every session's spill directory lives:
# <user cache>/relm/spill. `tools::R_user_dir()` is the base-R sanctioned
# per-user cache location (no extra dependency).
spill_root_dir <- function() {
  file.path(tools::R_user_dir("relm", "cache"), "spill")
}

# This session's spill directory path, unique per session (process id + a
# per-session token that does not perturb the user's RNG, so concurrent R sessions
# never share a directory). The path is only *computed* here; the engine creates
# the directory when it actually spills, so an in-memory trace (the common case,
# even at the default spill = TRUE) leaves no empty directory behind.
spill_session_dir <- function() {
  dir <- .relm_state$session_dir
  if (!is.null(dir)) {
    relm_check(rebirth_spill_prepare(dir))
    return(dir)
  }
  # basename(tempfile()) is unique within the session and uses tempfile's own
  # counter, so it does not touch (or reseed) the user's random-number state.
  token <- paste(Sys.getpid(), basename(tempfile("")), sep = "-")
  dir <- file.path(spill_root_dir(), token)
  relm_check(rebirth_spill_prepare(dir))
  .relm_state$session_dir <- dir
  dir
}

# The next spill file path (trace-<nonce>.arrow), unique across calls and sessions
# even when they share a custom directory. Written under `spill_dir` when the caller
# supplies one, else this session's managed directory (which cleanup removes at
# exit; a user-supplied directory is left untouched). The engine creates the
# directory and exclusively creates the file when it actually spills.
next_spill_path <- function(spill_dir = NULL) {
  fname <- paste0("trace-", next_trace_id(), ".arrow")
  if (is.null(spill_dir)) {
    file.path(spill_session_dir(), fname)
  } else {
    file.path(spill_dir, fname)
  }
}

# A per-trace nonce for a spill file's integrity footer, unique across sessions,
# processes, and calls. The old id was basename(spill_path) (trace-<n>.arrow), whose
# per-session counter restarts at 1 each session: two sessions writing to the same
# user-supplied spill_dir produced the same id, so a later trace's file could be
# read as an earlier trace object's activations (M-2). A nonce closes that: the
# process id separates processes, basename(tempfile("")) is unique per call within a
# session (and, being tempfile's own counter, does not perturb the user's RNG), and
# a high-resolution timestamp separates sessions that reuse a pid.
next_trace_id <- function() {
  paste(
    Sys.getpid(),
    basename(tempfile("")),
    sprintf("%.6f", as.numeric(Sys.time())),
    sep = "-"
  )
}

# Remove this session's spill directory (called by the exit finalizer). Best
# effort: never errors, so it is safe during R's shutdown.
cleanup_spill_session <- function() {
  dir <- .relm_state$session_dir
  if (!is.null(dir)) {
    tryCatch(relm_check(rebirth_spill_cleanup(dir)), error = function(e) NULL)
    .relm_state$session_dir <- NULL
  }
  invisible(NULL)
}

# Age is only a retention floor: native reclamation also requires an exclusive
# lifetime lease, valid managed marker and unchanged non-symlink identities.
# Unknown/legacy directories are intentionally retained, even when old.
sweep_old_spill_dirs <- function(max_age_days = 7) {
  root <- spill_root_dir()
  if (!dir.exists(root)) {
    return(invisible(NULL))
  }
  dirs <- list.dirs(root, full.names = TRUE, recursive = FALSE)
  keep <- .relm_state$session_dir
  cutoff <- Sys.time() - max_age_days * 24 * 60 * 60
  for (d in dirs) {
    if (!is.null(keep) && normalizePath(d, mustWork = FALSE) ==
      normalizePath(keep, mustWork = FALSE)) {
      next
    }
    tryCatch(relm_check(rebirth_spill_sweep(d, as.double(cutoff))),
      error = function(e) NULL)
  }
  invisible(NULL)
}

.onLoad <- function(libname, pkgname) {
  .relm_async$stopping <- FALSE
  .relm_async$unloaded <- FALSE
  # Register the exit-time cleanup on a sentinel environment: reg.finalizer with
  # onexit = TRUE runs cleanup_spill_session() when R shuts down normally.
  sentinel <- new.env(parent = emptyenv())
  reg.finalizer(sentinel, function(e) {
    if (!isTRUE(.relm_async$unloaded)) async_shutdown()
    cleanup_spill_session()
  }, onexit = TRUE)
  .relm_state$sentinel <- sentinel
  # Sweep spill directories orphaned by earlier crashed sessions (never errors).
  tryCatch(sweep_old_spill_dirs(), error = function(e) NULL)
  invisible(NULL)
}

.onUnload <- function(libpath) {
  # Keep the DLL mapped: existing llm external pointers still own finalizers
  # implemented there, even after native model resources have been released.
  async_shutdown()
  .relm_async$unloaded <- TRUE
  cleanup_spill_session()
}
