from pathlib import Path
import json,struct,hashlib,math
run=Path('/private/tmp/relm-f6e/ci-policy-diagnosis-20261008-170800');st=json.loads((run/'status.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in json.loads((run/'source-manifest.json').read_text()).items():assert sha(Path(p))==h
for row in st['stages']:assert sha(run/(row['name']+'.log'))==row['log_sha256'] and row['exit_code']==0
raw=(run/'new-diagnostic.log').read_text().splitlines();rs=[json.loads(x.split(' ',1)[1]) for x in raw if x.startswith('F6E_OUTPUT_POLICY_DIAGNOSTIC_ROW ')];assert rs==json.loads((run/'observations.json').read_text()) and len(rs)==12
bits=lambda xs:b''.join(struct.pack('<f',x) for x in xs)
lookup={(r['variant'],r['last_only'],r['repeat']):r for r in rs};rows=0;maxerr=0
for r in rs:
 assert len(r['final_logits'])==len(r['history_logits'])==48 and len(r['tokens'])==5
 assert all(math.isfinite(x) for k in ['final_logits','history_logits'] for x in r[k])
 for pair in r['site_rows']:
  assert all(len(pair[k])==32 for k in ['before','after','direction'])
  # Explicit left-to-right IEEE f64 operations, matching the frozen operator.
  # Python >=3.12 built-in sum uses a different compensated accumulation.
  dot=0.0
  for x,v in zip(pair['before'],pair['direction']):dot+=x*v
  assert dot==pair['dot']
  for x,y,v in zip(pair['before'],pair['after'],pair['direction']):
   expected=x if pair['coef']==0 else struct.unpack('<f',struct.pack('<f',x-(pair['coef']*v)*dot))[0]
   delta=abs(expected-y);assert delta<=2e-6*(1+abs(expected));maxerr=max(maxerr,delta);rows+=1
 for name in ['final_logits','history_logits']:
  assert bits(r[name])==bits(lookup[(r['variant'],r['last_only'],1-r['repeat'])][name])
summary={}
for variant in ['original','zero','active']:
 a=lookup[(variant,False,0)];b=lookup[(variant,True,0)]
 summary[variant]={name:max(abs(x-y) for x,y in zip(a[name],b[name])) for name in ['final_logits','history_logits']}
backend=[json.loads(x.split('F6E_OUTPUT_POLICY_DIAGNOSTIC_BACKEND ',1)[1]) for x in raw if 'F6E_OUTPUT_POLICY_DIAGNOSTIC_BACKEND ' in x];assert len(backend)==1
result={'status':'passed','scope':'New diagnostic execution/receipt integrity on local Mac CPU; no acceptance of the failing Linux pruning comparison','records':12,'same_row_values':rows,'same_row_max_abs':maxerr,'cross_output_policy_observations':summary,'backend':backend[0],'original_acceptance_assertion_unchanged':True,'linux_diagnosis_pending':True,'inspector_note':'Initial Python built-in compensated sum differed by 4.44e-16 from native sequential accumulation; explicit sequential accumulation matches exactly. No tolerance changed or native execution repeated.'}
(run/'owner-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
