.libPaths(c('/private/tmp/relm-f6e/r-state-api-resume-20261008-165326/library','/private/tmp/relm-service/library','/Users/alessandrovadala/Library/R/arm64/4.5/library',.libPaths()))
library(relm);library(testthat)
root<-'/Users/alessandrovadala/DOCUDESK/R-ebirth';out<-'/private/tmp/relm-f6e/pr63-failure-3a818f4/fixture-corrections'
cases<-list('test-projection-owners.R'=c('projection inventory binds actual metadata and accumulated residual owners','projection candidate wraps an independent un-hashed state and shares unchanged entries'),'test-directions-memory.R'='checksum byte caps precede writes and interrupt cleanup closes descriptors','test-llm-print.R'='print.llm reports the active-intervention count')
scratch<-file.path(out,'cases');dir.create(scratch)
for(f in c('helper-projection.R','helper-llm.R')) file.copy(file.path(root,'rebirth/tests/testthat',f),scratch)
for(f in names(cases)) {
 es<-as.list(parse(file.path(root,'rebirth/tests/testthat',f),keep.source=FALSE))
 es<-Filter(function(e)is.call(e)&&identical(e[[1L]],as.name('test_that'))&&as.character(e[[2L]])%in%cases[[f]],es)
 stopifnot(length(es)==length(cases[[f]]));target<-file.path(scratch,f)
 writeLines(unlist(lapply(es,deparse,width.cutoff=500L)),target)
 stopifnot(identical(as.list(parse(target,keep.source=FALSE)),es))
}
res<-test_dir(scratch,reporter='summary',load_package='none',stop_on_failure=FALSE,stop_on_warning=FALSE)
saveRDS(res,file.path(out,'results.rds'));s<-as.data.frame(res);write.csv(s,file.path(out,'results.csv'),row.names=FALSE)
stopifnot(nrow(s)==4L,all(s$failed==0),!any(s$error),!any(s$skipped),all(s$warning==0))
cat('FOUR_AFFECTED_FIXTURE_CASES_OK models=0 native_rebuild=0 reinstall=0\n')
