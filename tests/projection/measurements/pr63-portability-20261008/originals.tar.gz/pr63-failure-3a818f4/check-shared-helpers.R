root <- '/Users/alessandrovadala/DOCUDESK/R-ebirth'
out <- '/private/tmp/relm-f6e/pr63-failure-3a818f4'
.libPaths(c('/private/tmp/relm-f6e/public-library-review', '/private/tmp/relm-service/library', '/Users/alessandrovadala/Library/R/arm64/4.5/library', .libPaths()))
library(relm)
library(testthat)
files <- names(jsonlite::fromJSON(file.path(out, 'helper-originals/manifest.json')))
# Use the exact four saved originals; compare parsed expressions, excluding source references.
files <- list.files(file.path(out, 'helper-originals'), pattern='^test-.*[.]R$')
helpers <- list()
for (f in files) {
  old <- as.list(parse(file.path(out, 'helper-originals', f), keep.source=FALSE))
  new <- as.list(parse(file.path(root, 'rebirth/tests/testthat', f), keep.source=FALSE))
  is_test <- vapply(old, function(e) is.call(e) && identical(e[[1L]], as.name('test_that')), logical(1))
  stopifnot(identical(old[is_test], new))
  helpers <- c(helpers, old[!is_test])
}
shared <- as.list(parse(file.path(root, 'rebirth/tests/testthat/helper-projection.R'), keep.source=FALSE))
key <- function(e) as.character(e[[2L]])
stopifnot(length(shared)==8L, identical(sort(vapply(shared,key,'')), sort(vapply(helpers,key,''))))
for (e in shared) stopifnot(identical(e, helpers[[which(vapply(helpers,key,'')==key(e))]]))
cat('UNCHANGED_HELPERS 8; UNCHANGED_TEST_BODIES 4 files\n')
cases <- jsonlite::fromJSON(file.path(out, 'helper-failed-cases.json'))
scratch <- file.path(out, 'isolated-helper-cases'); dir.create(scratch, showWarnings=FALSE)
file.copy(file.path(root, 'rebirth/tests/testthat/helper-projection.R'), scratch, overwrite=TRUE)
selected <- 0L
for (f in unique(cases[,1L])) {
  es <- as.list(parse(file.path(root, 'rebirth/tests/testthat', f), keep.source=FALSE))
  names <- cases[cases[,1L]==f,2L]
  es <- Filter(function(e) is.call(e) && identical(e[[1L]], as.name('test_that')) && as.character(e[[2L]]) %in% names, es)
  stopifnot(length(es)==length(names)); selected <- selected+length(es)
  target <- file.path(scratch,f)
  writeLines(unlist(lapply(es,deparse, width.cutoff=500L)),target)
  stopifnot(identical(as.list(parse(target,keep.source=FALSE)),es))
}
stopifnot(selected==12L)
res <- testthat::test_dir(scratch, reporter='summary', stop_on_failure=TRUE, stop_on_warning=TRUE, load_package='none')
saveRDS(res,file.path(out,'shared-helpers-result.rds'))
writeLines('passed: 12 isolated affected test cases; eight unchanged helpers',file.path(out,'shared-helpers.status'))
