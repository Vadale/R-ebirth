test_that("projection inventory binds actual metadata and accumulated residual owners", {
    p <- projection_test_profile()
    facts <- list(hash_slots = 29, bindings = 2, c_finalizer_bytes = 8)
    s <- list(kind = "steer", layer = 2L, direction = c(2, 4, 6), coef = 0.5, positions = "all")
    m <- projection_owner_model(interventions = list(s))
    entry <- projection_owner_entry()
    got <- relm:::projection_owner_inventory(m, entry, facts, p, 64 * 2^20, 2^20)
    expect_gt(got$r_projection_fixed_bytes, 2 * as.double(object.size(m)))
    expect_identical(got$state_extra_bytes, 1272)
    expect_identical(got$scan_bytes, 2 * as.double(object.size(integer(32L))) + as.double(object.size(got$counts)) + as.double(object.size(facts)) + 2 * as.double(object.size(0)) + as.double(object.size(got)))
    flat <- list(steer_layers = 2L, steer_vectors = c(1, 2, 3), ablate_layers = integer(), ablate_neurons = integer(), ablate_values = double())
    expect_identical(got$r_adapter_bytes, as.double(object.size(s)) + as.double(object.size(flat)))
    wider <- m
    wider$.description <- strrep("x", 4000)
    more <- relm:::projection_owner_inventory(wider, entry, facts, p, 64 * 2^20, 2^20)
    expect_identical(more$r_projection_fixed_bytes - got$r_projection_fixed_bytes, 2 * (as.double(object.size(wider$.description)) - as.double(object.size(m$.description))))
    bad <- m
    bad$path <- new.env(parent = emptyenv())
    expect_error(relm:::projection_owner_inventory(bad, entry, facts, p, 64 * 2^20, 2^20), class = "relm_error_intervention")
    expect_error(relm:::projection_owner_inventory(m, entry, facts, p, 2^20, 2^20), class = "relm_error_oom")
})
test_that("projection candidate wraps an independent un-hashed state and shares unchanged entries", {
    m <- projection_owner_model()
    m$state$closed <- TRUE
    m$state$ptr <- m$ptr
    entry <- projection_owner_entry()
    ptr <- new("externalptr")
    derived <- relm:::projection_new_llm(m, ptr, entry, 64 * 2^20, 2^20)
    derived$state$closed <- TRUE
    expect_null(env.profile(derived$state))
    expect_identical(parent.env(derived$state), emptyenv())
    expect_identical(sort(ls(derived$state, all.names = TRUE)), c("closed", "ptr"))
    expect_false(identical(derived$state, m$state))
    expect_identical(derived$state$ptr, ptr)
    expect_identical(derived$interventions, list(entry))
    expect_length(m$interventions, 0L)
    expect_null(attr(m, "projection", exact = TRUE))
    expect_identical(relm:::projection_owner_settings(derived), list(max_bytes = 64 * 2^20, existing_direction_estimate = 2^20))
    for (name in relm:::projection_model_fields[!relm:::projection_model_fields %in% c("ptr", "state", "interventions")]) expect_identical(derived[[name]], m[[name]])
    next_entry <- entry
    next_entry$component <- "attn_out"
    facts <- list(hash_slots = 0, bindings = 2, c_finalizer_bytes = 8)
    inventory <- relm:::projection_owner_inventory(derived, next_entry, facts, projection_test_profile(), 64 * 2^20, 2^20)
    expect_identical(inventory$counts$previous_sites, 1)
    expect_identical(inventory$state_extra_bytes, 992)
    bad <- derived
    attr(bad, "projection")$hidden <- raw(100)
    expect_error(relm:::projection_owner_settings(bad), class = "relm_error_intervention")
})
