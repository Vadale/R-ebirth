test_that("explicit direction inheritance uses a new combined budget and production preflight", {
    e <- projection_binding_fixture()
    m <- projection_owner_model(interventions = list(projection_owner_entry()))
    attr(m, "projection") <- list(max_bytes = 32 * 2^20, existing_direction_estimate = 1024)
    entry <- list(kind = "steer", layer = 2L, direction = rep(0.25, 3), coef = 1, positions = "all")
    z <- e$projection_prepare(m, entry, 48 * 2^20, 2048, direction_application = TRUE)
    expect_identical(z$config$max_bytes, 48 * 2^20)
    expect_identical(z$config$existing_direction_estimate, 2048)
    expect_identical(z$response$inputs$production_armed, 1)
    expect_error(e$projection_prepare(m, entry, 48 * 2^20, 2048), class = "relm_error_intervention")
    original <- e$rebirth_projection_preflight
    e$rebirth_projection_preflight <- function(...) {
        r <- original(...)
        r$inputs$production_armed <- 0
        r
    }
    expect_error(e$projection_prepare(m, entry, 32 * 2^20, 1024), class = "relm_error_intervention")
})
