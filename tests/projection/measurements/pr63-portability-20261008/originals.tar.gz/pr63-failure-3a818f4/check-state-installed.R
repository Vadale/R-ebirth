args<-commandArgs(TRUE); root<-args[[1L]]; out<-args[[2L]]
library(relm); library(testthat)
e<-new.env(parent=baseenv())
for(f in list.files(file.path(root,'rebirth/R'),full.names=TRUE,pattern='[.]R$')) sys.source(f,e)
n<-ls(e,all.names=TRUE); functions<-n[vapply(mget(n,e),is.function,logical(1))]
for(k in functions) {a<-get(k,asNamespace('relm'),inherits=FALSE);stopifnot(identical(formals(a),formals(e[[k]])),identical(body(a),body(e[[k]])))}
codetools::checkUsagePackage('relm')
cat('CURRENT_INSTALLED_BODIES',length(functions),'\n')
cases<-jsonlite::fromJSON('/private/tmp/relm-f6e/pr63-failure-3a818f4/helper-failed-cases.json')
scratch<-file.path(out,'affected-r-cases');dir.create(scratch)
file.copy(file.path(root,'rebirth/tests/testthat/helper-projection.R'),scratch)
file.copy(file.path(root,'rebirth/tests/testthat/test-projection-state-api.R'),scratch)
for(f in unique(cases[,1L])) {
 es<-as.list(parse(file.path(root,'rebirth/tests/testthat',f),keep.source=FALSE)); names<-cases[cases[,1L]==f,2L]
 es<-Filter(function(e)is.call(e)&&identical(e[[1L]],as.name('test_that'))&&as.character(e[[2L]])%in%names,es)
 stopifnot(length(es)==length(names));target<-file.path(scratch,f)
 writeLines(unlist(lapply(es,deparse,width.cutoff=500L)),target)
 stopifnot(identical(as.list(parse(target,keep.source=FALSE)),es))
}
results<-testthat::test_dir(scratch,reporter='summary',stop_on_failure=TRUE,stop_on_warning=TRUE,load_package='none')
saveRDS(results,file.path(out,'affected-r-cases.rds'))
summary<-as.data.frame(results);write.csv(summary,file.path(out,'affected-r-summary.csv'),row.names=FALSE)
stopifnot(nrow(summary)==15L,all(summary$failed==0),!any(summary$error),!any(summary$skipped))
cat('STATE_INSTALLED_MODEL_FREE_OK cases=15 models=0\n')
