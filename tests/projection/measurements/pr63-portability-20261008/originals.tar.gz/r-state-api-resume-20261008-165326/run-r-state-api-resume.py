import fcntl,hashlib,json,os,re,shlex,shutil,signal,subprocess,tarfile,time,traceback
from pathlib import Path
ROOT=Path('/private/tmp/relm-f6e');REPO=Path('/Users/alessandrovadala/DOCUDESK/R-ebirth');WORK=REPO/'rebirth/src/rust'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 lock=(ROOT/'verify.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 binding=json.loads((ROOT/'r-state-api-resume-binding.json').read_text())
 for p,h in binding['sources'].items():assert sha(REPO/p)==h,p
 for p,h in binding['files'].items():assert sha(Path(p))==h,p
 run=ROOT/('r-state-api-resume-'+time.strftime('%Y%m%d-%H%M%S'));run.mkdir()
 state={'status':'running','pid':os.getpid(),'directory':str(run),'stages':[],'scope':'R state provenance factory/API compatibility and affected model-free R cases; no models/inference, no full old suites, no golden generation'}
 def save():
  data=json.dumps(state,indent=2)+'\n';(run/'status.json').write_text(data);tmp=ROOT/'r-state-api-status.tmp';tmp.write_text(data);tmp.replace(ROOT/'r-state-api-status.json')
 save();sources=binding['sources'];headers=binding['headers'];installed={}
 env=os.environ.copy();env['R_HOME']=subprocess.check_output(['R','RHOME'],text=True).strip()
 for k in list(env):
  if k.startswith(('RELM_TEST_MODEL_','RELM_TEST_MMPROJ_','F6E_MODEL')) or k=='RELM_NATIVE_SANITIZERS':env.pop(k)
 def stage(name,cmd,cwd=WORK,extra=None,timeout=1800):
  row={'name':name,'command':cmd,'status':'running'};state['stage']=name;state['stages'].append(row);save()
  with (run/(name+'.log')).open('w') as log:
   p=subprocess.Popen(cmd,cwd=cwd,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
   try:code=p.wait(timeout=timeout)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10);raise
  row.update(exit_code=code,status='passed' if code==0 else 'failed',log_sha256=sha(run/(name+'.log')));save()
  assert code==0,name+' failed; preserve and diagnose'
  return (run/(name+'.log')).read_text()
 try:
  (run/'source-manifest.json').write_text(json.dumps(sources,indent=2)+'\n')
  shutil.copy2(ROOT/'r-state-api-resume-binding.json',run/'binding.json')
  shutil.copy2(Path(__file__),run/Path(__file__).name)
  with tarfile.open(run/'source.tar.gz','w:gz') as tar:
   for p in sources:
    if p.startswith(('rebirth/R/','rebirth/src/rust/rebirth-ffi/','rebirth/tests/testthat/')):tar.add(REPO/p,arcname=p)
  (run/'candidate.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=REPO))
  parent=Path(binding['parent_run']);prior=json.loads((parent/'status.json').read_text())
  assert prior['status']=='failed' and prior['error']=='generated wrappers differ'
  previous=json.loads((parent/'source-manifest.json').read_text())
  changed=[p for p,h in previous.items() if sha(REPO/p)!=h]
  assert changed==['rebirth/R/extendr-wrappers.R'],changed
  binaries=json.loads((parent/'binary-bindings.json').read_text())
  dll=Path(binaries['dll']['path']);native_sha=binaries['dll']['sha256'];assert sha(dll)==native_sha
  for p,h in binaries['archives'].items():assert sha(Path(p))==h,p
  assert sha(Path(binaries['C_object']['path']))==binaries['C_object']['sha256']
  for row in prior['stages']:
   assert row['status']=='passed' and sha(parent/(row['name']+'.log'))==row['log_sha256']
   shutil.copy2(parent/(row['name']+'.log'),run/('carried-'+row['name']+'.log'))
  (run/'carried-native.json').write_text(json.dumps({'parent':str(parent),'stages':prior['stages'],'binding':binaries,'only_source_difference':changed},indent=2)+'\n')
  (run/'binary-bindings.json').write_text(json.dumps(binaries,indent=2)+'\n')
  assert (parent/'extendr-wrappers.R').read_bytes()==(REPO/'rebirth/R/extendr-wrappers.R').read_bytes()
  stage('compiled-profile',['Rscript','--vanilla',str(ROOT/'check-review-fix-profile.R'),str(dll),str(run)])
  package=run/'package-source';package.mkdir()
  for d in ['R','man','inst']:shutil.copytree(REPO/'rebirth'/d,package/d)
  for n in ['DESCRIPTION','NAMESPACE','LICENSE','NEWS.md']:shutil.copy2(REPO/'rebirth'/n,package/n)
  dest=package/'inst/libs';dest.mkdir();shutil.copy2(dll,dest/'relm.so')
  library=run/'library';library.mkdir();env['R_LIBS']=':'.join([str(library),'/private/tmp/relm-service/library','/Users/alessandrovadala/Library/R/arm64/4.5/library'])
  stage('fresh-install',['R','CMD','INSTALL','--no-configure','--no-libs','--library='+str(library),str(package)],REPO)
  assert sha(library/'relm/libs/relm.so')==native_sha
  installed={str(p.relative_to(library/'relm')):sha(p) for p in (library/'relm').rglob('*') if p.is_file()}
  (run/'installed-manifest.json').write_text(json.dumps(installed,indent=2)+'\n')
  text=stage('affected-r-cases',['Rscript','--vanilla',str(ROOT/'pr63-failure-3a818f4/check-state-installed.R'),str(REPO),str(run)],REPO)
  assert 'STATE_INSTALLED_MODEL_FREE_OK cases=15 models=0' in text
  state.update(status='awaiting_owner_verification',models=0,inference=0,installed_library=str(library),dll_sha256=native_sha,affected_r_cases=15)
 except Exception as e:state.update(status='failed',error=str(e),traceback=traceback.format_exc())
 finally:
  state['source_drift']=[p for p,h in sources.items() if sha(REPO/p)!=h]
  state['header_drift']=[p for p,h in headers.items() if sha(Path(p))!=h]
  if state['source_drift'] or state['header_drift']:state['status']='failed'
  state['finished_at']=time.time();save()
if __name__=='__main__':main()
