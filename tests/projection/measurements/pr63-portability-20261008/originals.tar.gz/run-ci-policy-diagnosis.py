import fcntl,hashlib,json,os,signal,subprocess,time,traceback
from pathlib import Path
ROOT=Path('/private/tmp/relm-f6e');REPO=Path('/Users/alessandrovadala/DOCUDESK/R-ebirth');WORK=REPO/'rebirth/src/rust'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 lock=(ROOT/'verify.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 bind=json.loads((ROOT/'ci-policy-diagnosis-binding.json').read_text())
 for p,h in bind['sources'].items():assert sha(REPO/p)==h,p
 run=ROOT/('ci-policy-diagnosis-'+time.strftime('%Y%m%d-%H%M%S'));run.mkdir()
 (run/'source-manifest.json').write_text(json.dumps(bind['sources'],indent=2)+'\n')
 (run/'binding.json').write_text(json.dumps(bind,indent=2)+'\n')
 st={'status':'running','pid':os.getpid(),'directory':str(run),'stages':[],'scope':'New output-policy localization only, original/zero/active; does not replace the failed bitwise acceptance test. No Qwen or frozen-reference producer.'}
 def save():
  s=json.dumps(st,indent=2)+'\n';(run/'status.json').write_text(s);t=ROOT/'ci-policy-diagnosis-status.tmp';t.write_text(s);t.replace(ROOT/'ci-policy-diagnosis-status.json')
 save();env=os.environ.copy();env['RUST_TEST_THREADS']='1'
 for k in list(env):
  if k.startswith(('RELM_TEST_MODEL_','RELM_TEST_MMPROJ_')):env.pop(k)
 try:
  for name,cmd in [('format',['cargo','fmt','--all','--check']),('diagnostic-format',['rustfmt','--edition','2021','--check','rebirth-llm/src/projection_policy_diagnostic.rs']),('clippy',['cargo','clippy','--offline','--locked','-p','rebirth-llm','--all-targets','--','-D','warnings']),('new-diagnostic',['cargo','test','--offline','--locked','-p','rebirth-llm','--lib','projection::tests::projection_output_policy_failure_diagnostic','--','--exact','--ignored','--nocapture'])]:
   row={'name':name,'command':cmd,'status':'running'};st['stage']=name;st['stages'].append(row);save()
   with (run/(name+'.log')).open('w') as log:
    p=subprocess.Popen(cmd,cwd=WORK,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
    try:rc=p.wait(timeout=1200)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10);raise
   row.update(exit_code=rc,status='passed' if rc==0 else 'failed',log_sha256=sha(run/(name+'.log')));save();assert rc==0,name
  lines=(run/'new-diagnostic.log').read_text().splitlines()
  records=[json.loads(x.split(' ',1)[1]) for x in lines if x.startswith('F6E_OUTPUT_POLICY_DIAGNOSTIC_ROW ')]
  assert len(records)==12 and len({(r['variant'],r['last_only'],r['repeat']) for r in records})==12
  assert lines.count('F6E_OUTPUT_POLICY_DIAGNOSTIC_COMPLETE records=12 tiny_loads=1 constructors=2 acceptance_replaced=0')==1
  (run/'observations.json').write_text(json.dumps(records,indent=2)+'\n')
  st.update(status='awaiting_owner_verification',records=12,tiny_load_attempts=1,derive_attempts=2)
 except Exception as e:st.update(status='failed',error=str(e),traceback=traceback.format_exc())
 finally:
  st['source_drift']=[p for p,h in bind['sources'].items() if sha(REPO/p)!=h]
  if st['source_drift']:st['status']='failed'
  st['finished_at']=time.time();save()
if __name__=='__main__':main()
