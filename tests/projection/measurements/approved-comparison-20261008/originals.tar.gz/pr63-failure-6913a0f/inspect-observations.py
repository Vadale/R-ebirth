import csv,json,struct,math,hashlib
from pathlib import Path
b=Path('/private/tmp/relm-f6e/pr63-failure-6913a0f');g=Path('tests/llm-golden/projection/goldens');a=b/'reference/failed-generated'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=(b/'policy/native.log').read_text().splitlines();tag='F6E_OUTPUT_POLICY_DIAGNOSTIC_ROW '
rs=[json.loads(x.split(tag,1)[1]) for x in raw if tag in x];assert len(rs)==12
lookup={(r['variant'],r['last_only'],r['repeat']):r for r in rs}
bits=lambda xs:b''.join(struct.pack('<f',x) for x in xs)
coords=0;maxerr=0
for r in rs:
 for k in ['final_logits','history_logits']:
  assert len(r[k])==48 and all(map(math.isfinite,r[k]))
  assert bits(r[k])==bits(lookup[(r['variant'],r['last_only'],1-r['repeat'])][k])
 for pair in r['site_rows']:
  assert all(len(pair[k])==32 for k in ['before','after','direction'])
  dot=0.
  for x,v in zip(pair['before'],pair['direction']):dot+=x*v
  assert dot==pair['dot']
  for x,y,v in zip(pair['before'],pair['after'],pair['direction']):
   expected=x if pair['coef']==0 else struct.unpack('<f',struct.pack('<f',x-pair['coef']*v*dot))[0]
   delta=abs(expected-y);assert delta<=2e-6*(1+abs(expected));maxerr=max(maxerr,delta);coords+=1
policy={}
for variant in ['original','zero','active']:
 p=lookup[(variant,False,0)];q=lookup[(variant,True,0)]
 policy[variant]={k:dict(max_abs=max(abs(x-y) for x,y in zip(p[k],q[k])),different_bits=sum(bits([x])!=bits([y]) for x,y in zip(p[k],q[k]))) for k in ['final_logits','history_logits']}
for last in [False,True]:
 for k in ['final_logits','history_logits']:assert bits(lookup[('original',last,0)][k])==bits(lookup[('zero',last,0)][k])
compare={}
for name in ['controls.csv','forward-logits.csv','forward-row-witnesses.csv']:
 aa=list(csv.reader((a/name).open()));gg=list(csv.reader((g/name).open()));assert len(aa)==len(gg) and aa[0]==gg[0]
 nums=[];other=[];fields={}
 for row,(ar,gr) in enumerate(zip(aa[1:],gg[1:]),2):
  assert len(ar)==len(gr)
  for col,(av,gv) in enumerate(zip(ar,gr)):
   if av==gv:continue
   field=aa[0][col];fields[field]=fields.get(field,0)+1
   try:
    avn=float(av);gvn=float(gv);assert math.isfinite(avn) and math.isfinite(gvn)
    nums.append(dict(row=row,field=field,actual=av,expected=gv,absolute=abs(avn-gvn)))
   except (ValueError,AssertionError):other.append(dict(row=row,field=field,actual=av,expected=gv))
 compare[name]=dict(rows=len(aa)-1,numeric_differences=len(nums),other_differences=other,fields=fields,max_abs=max([x['absolute'] for x in nums],default=0),largest=sorted(nums,key=lambda x:x['absolute'],reverse=True)[:5])
meta=[]
def walk(x,y,path=''):
 if type(x)!=type(y):meta.append(dict(path=path,actual=x,expected=y));return
 if isinstance(x,dict):
  assert x.keys()==y.keys()
  for k in x:walk(x[k],y[k],path+'/'+k)
 elif isinstance(x,list):
  assert len(x)==len(y)
  for k,(xx,yy) in enumerate(zip(x,y)):walk(xx,yy,path+'/'+str(k))
 elif x!=y:meta.append(dict(path=path,actual=x,expected=y))
walk(json.loads((a/'manifest.json').read_text()),json.loads((g/'manifest.json').read_text()))
original=json.loads((b/'reference/input-hashes.json').read_text());assert original['goldens']=={p.name:sha(p) for p in g.iterdir() if p.is_file()}
out=dict(status='diagnostic_observations_verified_not_acceptance',policy=policy,records=len(rs),same_policy_replay='bitwise',zero_original_same_policy='bitwise',same_row_coordinates=coords,same_row_max_abs=maxerr,reference_csv=compare,reference_metadata=meta,raw_hashes={str(p.relative_to(b)):sha(p) for p in b.rglob('*') if p.is_file()})
(b/'observations-verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['raw_hashes']},indent=2))
