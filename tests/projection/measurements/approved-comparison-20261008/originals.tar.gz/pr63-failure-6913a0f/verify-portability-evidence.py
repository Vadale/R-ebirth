from pathlib import Path
import csv,json,hashlib,math
b=Path('/private/tmp/relm-f6e/pr63-failure-6913a0f');g=Path('tests/llm-golden/projection/goldens');a=b/'reference/failed-generated';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
o=json.loads((b/'observations-verification.json').read_text());assert len(o['reference_metadata'])==514
for root in [a,g]:
 rows=list(csv.DictReader((root/'manifest.csv').open()))
 assert len(rows)==44 and len({r['file'] for r in rows})==44
 assert {r['file'] for r in rows}=={p.name for p in root.iterdir() if p.name!='manifest.csv'}
 for r in rows:assert sha(root/r['file'])==r['sha256'] and (root/r['file']).stat().st_size==int(r['bytes'])
actual=list(csv.DictReader((a/'controls.csv').open()));expected=list(csv.DictReader((g/'controls.csv').open()))
assert len(actual)==191 and len({r['control'] for r in actual})==191
assert [(r['control'],r['outcome']) for r in actual]==[(r['control'],r['outcome']) for r in expected]
assert all(r['outcome']=='passed' for r in actual)
for r in o['reference_metadata']:
 assert r['path'].startswith('/cases/')
 assert all(isinstance(r[k],float) and math.isfinite(r[k]) for k in ['actual','expected'])
 assert abs(r['actual']-r['expected'])<=1e-12*(1+abs(r['expected']))
for r in o['reference_csv']['controls.csv']['other_differences']:
 av=json.loads(r['actual']);ev=json.loads(r['expected']);assert len(av)==len(ev)==2
 assert all(math.isfinite(x) and math.isfinite(y) and abs(x-y)<=1e-12*(1+abs(y)) for x,y in zip(av,ev))
backendtag='F6E_OUTPUT_POLICY_DIAGNOSTIC_BACKEND '
backend=[json.loads(x.split(backendtag,1)[1]) for x in (b/'policy/native.log').read_text().splitlines() if backendtag in x];assert len(backend)==1
receipt=dict(status='observations_verified_acceptance_unchanged_and_failed',source_head='6913a0f3f7341e71ab4540e515461de6a59db99d',merge_checkout='f955d40c0916dd41a14b101f93dacaed0804c841',merge_tree_matches_head=True,reference_files=45,reference_exact_files=40,each_manifest_rows=44,named_controls=191,control_outcomes='all passed; strict byte gate failed',metadata_numeric_changes=514,metadata_non_numeric_changes=0,forward_logit_numeric_changes=2479,forward_logit_max_abs=1.7763568394002505e-15,forward_witness_norm_changes=2,policy=o['policy'],same_policy_replay='bitwise',zero_vs_original_same_policy='bitwise',same_row_coordinates=256,same_row_max_abs=0,backend=backend[0],limitations=['Different actual builds: Linux OpenBLAS versus original Mac Accelerate. No isolated BLAS-only causal experiment.','Original and zero both differ across output policies; this does not prove a specific kernel cause or general harmlessness.','The old strict byte/bit criteria remain failed. Applying different comparison semantics requires founder approval.'])
(b/'independent-observation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['backend','policy','limitations']},indent=2))
