import json,os,subprocess,time
from pathlib import Path
out=Path('/private/tmp/relm-f6e/approved-comparison-20261008')
work=Path('/Users/alessandrovadala/DOCUDESK/R-ebirth/rebirth/src/rust')
s={'status':'running','pid':os.getpid(),'stages':[],'scope':'Affected pruning gate with approved numeric cross-policy comparison and new exact same-policy zero controls; no reference producer/Qwen'}
def save():
 p=out/'native-status.tmp';p.write_text(json.dumps(s,indent=2)+'\n');p.replace(out/'native-status.json')
env=os.environ.copy();env['RUST_TEST_THREADS']='1';save()
try:
 for name,args in [('format',['cargo','fmt','--all','--check']),('clippy',['cargo','clippy','--offline','--locked','-p','rebirth-llm','--all-targets','--','-D','warnings']),('pruning',['cargo','test','--offline','--locked','-p','rebirth-llm','--lib','projection::tests::projection_microbatches_pruning_and_graph_reuse','--','--exact','--nocapture'])]:
  s['current_stage']=name;save()
  with (out/(name+'.log')).open('w') as log:r=subprocess.run(args,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
  s['stages'].append({'name':name,'exit_code':r.returncode,'command':args});save()
  if r.returncode:raise RuntimeError(name)
 s['status']='completed'
except Exception as e:s.update(status='failed',error=str(e))
s['finished_at']=time.time();save()
