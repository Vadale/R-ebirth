.relm_lifecycle_started <- proc.time()
.relm_lifecycle_step <- function(phase, label) {
  t <- proc.time() - .relm_lifecycle_started
  cat(sprintf('ASYNC_STAGE %s elapsed=%.3f cpu=%.3f %s\n', phase, t[['elapsed']], t[['user.self']] + t[['sys.self']], label))
  flush(stdout())
}
.relm_lifecycle_step('begin', 'load namespaces')
.libPaths(c("D:/temp/2026_10_19_18_49_01_2369/RtmpWAUjVc/RLIBS_268dc2a28919", 
"D:/RCompile/recent/R/library"))
library(relm)
stopifnot(requireNamespace('later'), requireNamespace('promises'))
.relm_lifecycle_step('end', 'load namespaces')
new_fixture <- function(mode = 'success', steps = 100L, delay = 2L) {
  m <- relm:::new_llm(relm:::relm_check(relm:::rebirth_async_test_handle()), '<fixture>')
  relm:::relm_check(relm:::rebirth_async_test_config(m$ptr, mode, steps, delay))
  m
}
observe <- function(p, diagnostic = FALSE) {
  x <- new.env(); x$done <- FALSE; x$count <- 0L
  observer <- promises::then(p, function(value) { x$value <- value; x$count <- x$count + 1L; x$done <- TRUE; NULL },
    function(error) { x$error <- error; x$count <- x$count + 1L; x$done <- TRUE; NULL })
  if (diagnostic) { x$parent <- p; x$observer <- observer }
  x
}
drain <- function(x, timeout = 10) {
  started <- proc.time(); until <- started[['elapsed']] + timeout
  samples <- transitions <- list(); previous <- NULL; polls <- 0L; max_pump <- 0
  snapshot <- function() list(native = relm:::rebirth_async_test_stats(),
    job_present = !is.null(relm:::.relm_async$job), done = x$done, count = x$count,
    parent = attr(x$parent, 'promise_impl')$status(),
    observer = attr(x$observer, 'promise_impl')$status())
  while (!x$done && proc.time()[['elapsed']] < until) {
    before <- proc.time()[['elapsed']]; later::run_now(0.05)
    if (!is.null(x$parent)) {
      timing <- proc.time() - started; pump <- proc.time()[['elapsed']] - before
      polls <- polls + 1L; max_pump <- max(max_pump, pump); state <- snapshot()
      sample <- c(list(elapsed = timing[['elapsed']], cpu = timing[['user.self']] +
        timing[['sys.self']], pump = pump), state)
      samples <- tail(c(samples, list(sample)), 8L)
      if (!identical(state, previous)) transitions <- c(transitions, list(sample))
      previous <- state
    }
  }
  if (!is.null(x$parent)) {
    timing <- proc.time() - started
    queue <- tryCatch(lapply(getFromNamespace('list_queue', 'later')(
      later::current_loop()), function(item) item[c('id', 'when')]), error = conditionMessage)
    x$diagnostic <- c(list(timeout = timeout, elapsed = timing[['elapsed']],
      cpu = timing[['user.self']] + timing[['sys.self']], polls = polls, max_pump = max_pump,
      current_loop = later::current_loop()$id, global_loop = later::global_loop()$id,
      last_polls = samples, transitions = transitions, queue = queue,
      R = R.version.string, later = as.character(packageVersion('later')),
      promises = as.character(packageVersion('promises'))), snapshot())
    cat('ASYNC_LIFECYCLE_DRAIN_DIAGNOSTIC\n'); dput(x$diagnostic); flush(stdout())
  }
  stopifnot(x$done, x$count == 1L, is.null(relm:::.relm_async$job))
}
.relm_lifecycle_budget_start <- proc.time()[['elapsed']]
.relm_lifecycle_step('begin', "lifecycle 001 foreign <- getDLLRegisteredRoutines(\"stats\")$.Call[[1]]$address")
foreign <- getDLLRegisteredRoutines("stats")$.Call[[1]]$address
.relm_lifecycle_step('end', "lifecycle 001 foreign <- getDLLRegisteredRoutines(\"stats\")$.Call[[1]]$address")
.relm_lifecycle_step('begin', "lifecycle 002 stopifnot(typeof(foreign) == \"externalptr\")")
stopifnot(typeof(foreign) == "externalptr")
.relm_lifecycle_step('end', "lifecycle 002 stopifnot(typeof(foreign) == \"externalptr\")")
.relm_lifecycle_step('begin', "lifecycle 003 for (ptr in list(foreign, new(\"externalptr\"), NULL)) {")
for (ptr in list(foreign, new("externalptr"), NULL)) {
    for (fun in list(relm:::rebirth_async_ready, relm:::rebirth_async_cancel)) {
        payload <- fun(ptr)
        stopifnot(identical(payload$ok, FALSE), identical(payload$class, "relm_error_closed"))
    }
    relm:::rebirth_handle_close(ptr)
}
.relm_lifecycle_step('end', "lifecycle 003 for (ptr in list(foreign, new(\"externalptr\"), NULL)) {")
.relm_lifecycle_step('begin', "lifecycle 004 gc()")
gc()
.relm_lifecycle_step('end', "lifecycle 004 gc()")
stopifnot(proc.time()[['elapsed']] - .relm_lifecycle_budget_start <= 30)
cat('ASYNC_LIFECYCLE_OK\n')
