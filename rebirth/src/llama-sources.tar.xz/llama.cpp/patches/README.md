# patches/

Provenance diffs for the vendored llama.cpp (DECISIONS.md D-006, D-012, D-015;
ARCHITECTURE.md §5). **The patches are applied to the committed `src/llama.cpp/`
tree** (D-015) — `build.rs` compiles the tree as-is, with no build-time patch
step and no diff-applier dependency (CRAN/`R CMD INSTALL`-robust). Each `*.diff`
here is the human-readable delta of the committed tree against pristine upstream
`b10828`, kept so the quarterly `vendor-bump` skill stays mechanical.

Paths in each diff are relative to `rebirth/src/llama.cpp/` (`git diff
--relative`), so from this directory's parent:

```sh
git apply    patches/<name>.diff   # re-apply to a fresh upstream checkout
git apply -R patches/<name>.diff   # revert to pristine upstream
```

## Applied patches

| Patch | Files/hunks | ADR |
|---|---|---|
| `0001-rebirth-wp5-ablation-intervene.diff` | 7 files, 14 hunks — `llama_adapter_intervene` at `build_cvec` for `llm_ablate()` | D-012 / D-016 |

| `0003-ggml-graph-size-offsets.diff` | One graph-storage sizing function | D-039 |
| `0004-cpu-callback-signatures.diff` | Seven CPU callback adapters and assignments | D-040 |

Every WP5 hunk also carries an inline `rebirth WP5` code comment
stating why it exists. The un-intervened forward pass is byte-identical to the
unpatched build: the `intervene->apply_to` no-op emits no graph node. The
existing synthetic goldens must pass unchanged on every bump. Patch 0002 is
retired under D-032 because b10828 provides the library-only mtmd build upstream.

| `0007-gguf-cerrno.diff` | Direct `<cerrno>` include for the existing file-open error diagnostic | D-058 |

## Integrity

`verify_vendored_tree.sh` asserts, and CI runs (the `vendored-tree` job):

- **G4 (D-008):** the committed tree hashes to `VENDORING.md`'s post-patch SHA.
- **Coherence (D-015):** reverse-applying `*.diff` reproduces the pre-patch SHA.

`VENDORING.md` records all three SHAs (upstream tarball, pre-patch tree,
post-patch tree). WP4 added zero patches (observation is zero-patch, D-012); this
WP5 ablation hook is the project's first vendored patch.

- `0008-engine-boundaries.diff`: D-059 narrow upstream safety backports for
  candidate recursion, M-RoPE merge tiles and Metal scalar index widths. The
  source-derived regressions run in the existing Rust Linux/native Mac jobs.
  This is not an engine version update or a regenerated numerical oracle.

- `0009-standard-header-dependencies.diff`: D-061 direct `<cstdlib>` dependencies
  in the graph header, memory mapping and vocabulary. Standard environment,
  allocation and integer-conversion calls are qualified. This preserves behavior
  and supports libc++23 without restoring removed transitive includes or changing
  compiler flags. See `tests/cran/README-engine-headers.md` for the regression.
